// routes/pieChartData.js
const express = require('express');
const moment = require('moment');
const Transaction = require('../models/Transaction');

const router = express.Router();

router.get('/pie-chart', async (req, res) => {
  const { month } = req.query;

  if (!month || !moment(month, 'MMMM', true).isValid()) {
    return res.status(400).json({ message: 'Invalid month parameter' });
  }

  try {
    const startDate = moment().month(month).startOf('month').toDate();
    const endDate = moment().month(month).endOf('month').toDate();

    const transactions = await Transaction.find({
      dateOfSale: { $gte: startDate, $lte: endDate }
    });

    const categoryCounts = transactions.reduce((acc, transaction) => {
      const category = transaction.category;
      if (category) acc[category] = (acc[category] || 0) + 1;
      return acc;
    }, {});

    res.status(200).json(categoryCounts);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching pie chart data' });
  }
});

module.exports = router;
