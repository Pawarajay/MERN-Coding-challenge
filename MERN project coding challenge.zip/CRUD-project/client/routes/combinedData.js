// routes/combinedData.js
const express = require('express');
const Transaction = require('../models/Transaction');
const moment = require('moment');
const statisticsRoute = require('./statistics');
const barChartDataRoute = require('./barChartData');
const pieChartDataRoute = require('./pieChartData');

const router = express.Router();

router.get('/combined', async (req, res) => {
  const { month } = req.query;

  if (!month || !moment(month, 'MMMM', true).isValid()) {
    return res.status(400).json({ message: 'Invalid month parameter' });
  }

  try {
    const statistics = await statisticsRoute(req, res);
    const barChartData = await barChartDataRoute(req, res);
    const pieChartData = await pieChartDataRoute(req, res);

    res.status(200).json({
      statistics,
      barChartData,
      pieChartData
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching combined data' });
  }
});

module.exports = router;
