// routes/statistics.js
const express = require('express');
const moment = require('moment');
const Transaction = require('../models/Transaction');

const router = express.Router();

router.get('/statistics', async (req, res) => {
  const { month } = req.query;

  if (!month || !moment(month, 'MMMM', true).isValid()) {
    return res.status(400).json({ message: 'Invalid month parameter' });
  }

  try {
    const startDate = moment().month(month).startOf('month').toDate();
    const endDate = moment().month(month).endOf('month').toDate();

    const transactions = await Transaction.find({
      dateOfSale: { $gte: startDate, $lte: endDate }
    });

    const totalSaleAmount = transactions.reduce((sum, transaction) => sum + transaction.price, 0);
    const soldItems = transactions.filter(transaction => transaction.price > 0).length;
    const unsoldItems = transactions.filter(transaction => transaction.price === 0).length;

    res.status(200).json({
      totalSaleAmount,
      soldItems,
      unsoldItems
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching statistics' });
  }
});

module.exports = router;
