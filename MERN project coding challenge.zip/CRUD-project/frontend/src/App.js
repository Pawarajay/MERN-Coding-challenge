import React, { useState } from 'react';
import TransactionsTable from './components/TransactionsTable';
import Statistics from './components/Statistics';
import BarChart from './components/BarChart';
import PieChart from './components/PieChart';

const App = () => {
  const [selectedMonth, setSelectedMonth] = useState('March');

  const handleMonthChange = (event) => {
    setSelectedMonth(event.target.value);
  };

  return (
    <div className="App">
      <h1>Product Transactions Dashboard</h1>
      <label>Select Month: </label>
      <select value={selectedMonth} onChange={handleMonthChange}>
        {['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map((month) => (
          <option key={month} value={month}>{month}</option>
        ))}
      </select>

      <Statistics month={selectedMonth} />
      <BarChart month={selectedMonth} />
      <PieChart month={selectedMonth} />
      <TransactionsTable month={selectedMonth} />
    </div>
  );
};

export default App;
