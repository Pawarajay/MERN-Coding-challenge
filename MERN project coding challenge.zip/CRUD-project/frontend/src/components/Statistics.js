import React, { useState, useEffect } from "react";
import axios from "axios";

const Statistics = ({ month }) => {
  const [stats, setStats] = useState({
    totalSales: 0,
    soldItems: 0,
    unsoldItems: 0,
  });

  useEffect(() => {
    const fetchStatistics = async () => {
      const response = await axios.get(`/api/statistics`, {
        params: { month },
      });
      setStats(response.data);
    };
    fetchStatistics();
  }, [month]);

  return (
    <div>
      <h2>Statistics for {month}</h2>
      <p>Total Sales Amount: {stats.totalSales}</p>
      <p>Total Sold Items: {stats.soldItems}</p>
      <p>Total Unsold Items: {stats.unsoldItems}</p>
    </div>
  );
};

export default Statistics;
