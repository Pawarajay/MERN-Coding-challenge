import React, { useState, useEffect } from 'react';
import { Bar } from 'react-chartjs-2';
import axios from 'axios';

const BarChart = ({ month }) => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchBarChartData = async () => {
      const response = await axios.get(`/api/bar-chart`, { params: { month } });
      setData(response.data);
    };
    fetchBarChartData();
  }, [month]);

  const chartData = {
    labels: ['0-100', '101-200', '201-300', '301-400', '401-500', '501-600', '601-700', '701-800', '801-900', '901+'],
    datasets: [
      {
        label: 'Price Range Count',
        data: data.map((item) => item.count),
        backgroundColor: 'rgba(75,192,192,1)',
      },
    ],
  };

  return <Bar data={chartData} />;
};

export default BarChart;
